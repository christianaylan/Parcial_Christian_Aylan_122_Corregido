package aylan_christian_parcial;

/**
 * Aventurero con atributo de mana
 */
public class Mago extends Aventurero {

    private final int mana;

    /**
     * Crea un mago
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param mana cantidad de mana (mayor que cero)
     * @throws IllegalArgumentException si algun campo invalido o el mana es
     * menor o igual a cero
     */
    public Mago(String codigo, String nombre, Rango rango, int mana) {
        super(codigo, nombre, rango);
        validarNumPositivo(mana, "mana del mago");
        this.mana = mana;
    }

    public int getMana() {
        return mana;
    }

    @Override
    public String atacar() {
        return getNombre() + " lanza un hechizo";
    }

    /**
     * @return mana + 10
     */
    @Override
    public int poderDeCombate() {
        return mana + 10;
    }

    @Override
    protected String descripcionClase() {
        return "mana=" + mana;
    }
}
