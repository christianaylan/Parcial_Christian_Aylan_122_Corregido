package aylan_christian_parcial;

/**
 * Aventurero con atributo de precision
 */
public class Arquero extends Aventurero implements Entrenable {

    private final int precision;

    /**
     * Crea un arquero
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param precision puntos en precision (mayor que cero)
     * @throws IllegalArgumentException si algun campo invalido o el mana es
     * menor o igual a cero
     */
    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        validarNumPositivo(precision, "precision del arquero");
        this.precision = precision;
    }

    public int getPrecision() {
        return precision;
    }

    @Override
    public String atacar() {
        return getNombre() + " dispara una flecha";
    }

    /**
     * @return precision * 3
     */
    @Override
    public int poderDeCombate() {
        return precision * 3;
    }

    @Override
    public String entrenar() {
        return this.getNombre() + " practica la punteria a larga distancia";
    }

    @Override
    protected String descripcionClase() {
        return "precision=" + precision;
    }
}
