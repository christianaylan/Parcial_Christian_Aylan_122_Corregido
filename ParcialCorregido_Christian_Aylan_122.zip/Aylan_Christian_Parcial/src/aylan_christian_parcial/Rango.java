package aylan_christian_parcial;

/**
 * Rango que puede tener un aventurero, de menor a mayor: BRONCE, PLATA Y ORO
 */
public enum Rango {
    BRONCE,
    PLATA,
    ORO
}
