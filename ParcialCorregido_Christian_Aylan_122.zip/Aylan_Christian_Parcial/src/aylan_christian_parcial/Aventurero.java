package aylan_christian_parcial;

import java.util.Objects;

/**
 * Atributos que comparten todos los aventureros, se consideran iguales los que
 * tengan el mismo codigo y nombre
 */
public abstract class Aventurero {

    private final String codigo;
    private final String nombre;
    private final Rango rango;

    /**
     * Crea un aventurero validando sus datos
     *
     * @param codigo codigo de identificacion (no puede ser nulo ni en blanco)
     * @param nombre nombre del aventurero (no puede ser nulo ni en blanco)
     * @param rango rango del aventurero (obligatorio)
     * @throws IllegalArgumentException si el codigo o nombre son nulos o en
     * blanco
     * @throws NullPointerException si el rango es nulo
     */
    public Aventurero(String codigo, String nombre, Rango rango) {
        validarTexto(codigo, "codigo");
        validarTexto(nombre, "nombre");
        Objects.requireNonNull(rango, "el rango es obligatorio");
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }

    /**
     * calcula el poder de combate segun el aventurero
     *
     * @return poder de combate
     */
    public abstract int poderDeCombate();

    /**
     * describe el atacar del aventurero
     *
     * @return texto de atacar
     */
    public abstract String atacar();

    /**
     * Devuelve los detalles de los atributos propios de la clase
     *
     * @return texto con las caracteristicas particulares
     */
    protected abstract String descripcionClase();

    /**
     * valida que la palabra ingresada no sea nula ni en blanco
     *
     * @param palabra palabra a validar
     * @param campo sector donde se ingresa la palabra
     * @throws IllegalArgumentException si la palabra es nula o esta en blanco
     */
    protected static void validarTexto(String palabra, String campo) {
        if (palabra == null || palabra.isBlank()) {
            throw new IllegalArgumentException("El campo " + campo + " no puede ser null ni estar en blanco");
        }
    }

    /**
     * valida que el numero ingresado sea mayor a cero
     *
     * @param num numero a validar
     * @param campo sector donde se ingresa el numero
     * @throws IllegalArgumentException si el numero es menor o igual a cero
     */
    protected static void validarNumPositivo(int num, String campo) {
        if (num <= 0) {
            throw new IllegalArgumentException("El valor de " + campo + " no puede ser menor o igual a cero");
        }
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof Aventurero otroAv
                && codigo.equals(otroAv.codigo) && nombre.equals(otroAv.nombre));
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " {codigo=" + codigo + ", nombre="
                + nombre + ", rango=" + rango + ", " + descripcionClase() + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }
}
