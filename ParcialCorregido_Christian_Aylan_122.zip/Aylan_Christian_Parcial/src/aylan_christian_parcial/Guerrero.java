package aylan_christian_parcial;

/**
 * Aventurero con atributo de fuerza
 */
public class Guerrero extends Aventurero implements Entrenable {

    private final int fuerza;

    /**
     * Crea un guerrero
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param fuerza valor de la fuerza (mayor que cero)
     * @throws IllegalArgumentException si algun campo invalido o la fuerza es
     * menor o igual a cero
     */
    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarNumPositivo(fuerza, "fuerza del guerrero");
        this.fuerza = fuerza;
    }

    public int getFuerza() {
        return fuerza;
    }

    @Override
    public String atacar() {
        return getNombre() + " ataca con la espada";
    }

    /**
     * @return fuerza * 2
     */
    @Override
    public int poderDeCombate() {
        return fuerza * 2;
    }

    @Override
    public String entrenar() {
        return this.getNombre() + " practica combate cuerpo a cuerpo";
    }

    @Override
    protected String descripcionClase() {
        return "fuerza=" + fuerza;
    }
}
