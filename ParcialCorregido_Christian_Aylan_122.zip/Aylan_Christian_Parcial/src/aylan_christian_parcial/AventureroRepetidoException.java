package aylan_christian_parcial;

/**
 * Excepcion que se lanza al intentar agregar un aventurero ya existente
 * (codigo, nombre) a la coleccion
 */
public class AventureroRepetidoException extends Exception {

    private static final String MESSAGE = "Ya existe un aventurero con el mismo codigo y nombre";

    public AventureroRepetidoException() {
        super(MESSAGE);
    }

    public AventureroRepetidoException(String codigo, String nombre) {
        super(MESSAGE + ": " + codigo + ", " + nombre);
    }
}
