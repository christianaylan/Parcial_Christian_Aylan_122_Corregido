package aylan_christian_parcial;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Gremio que crea y administra a los aventureros
 */
public class GremioAventureros {

    private final String nombre;
    private final List<Aventurero> aventureros;

    /**
     * Crea un gremio con un nombre (no null ni en blanco)
     *
     * @param nombre nombre del gremio
     * @throws IllegalArgumentException si el nombre es nulo o esta en blanco
     */
    public GremioAventureros(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        aventureros = new ArrayList<>();
    }

    private static void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("nombre de gremio nulo o vacio");
        }
    }

    public String getNombre() {
        return nombre;
    }

    /**
     * Registra un aventurero
     *
     * @param aventurero aventurero a registrar
     * @throws AventureroRepetidoException ya existe en la coleccion un elemento
     * con el mismo nombre y codigo
     */
    public void agregarAventurero(Aventurero aventurero) throws AventureroRepetidoException {
        Objects.requireNonNull(aventurero, "El aventurero no puede ser nulo");
        if (aventureros.contains(aventurero)) {
            throw new AventureroRepetidoException(aventurero.getCodigo(), aventurero.getNombre());
        }
        aventureros.add(aventurero);
    }

    /**
     * @return una copia de la coleccion de aventureros
     */
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }

    /**
     * retorna los aventureros con el poder solicitado como minimo
     *
     * @param poder poder minimo
     * @return una lista de aventureros con el poder mayor o igual al recibido
     */
    public List<Aventurero> obtenerAventurerosPoderosos(int poder) {
        List<Aventurero> resultado = new ArrayList<>();
        for (Aventurero av : aventureros) {
            if (av.poderDeCombate() >= poder) {
                resultado.add(av);
            }
        }
        return resultado;
    }

    /**
     * retorna una lista de aventureros filtrados por rango
     *
     * @param rango rango buscado
     * @return aventureros con el rango buscado
     */
    public List<Aventurero> filtrarPorRango(Rango rango) {
        Objects.requireNonNull(rango, "El rango no puede ser nulo");
        List<Aventurero> lista = new ArrayList<>();
        for (Aventurero av : aventureros) {
            if (av.getRango() == rango) {
                lista.add(av);
            }
        }
        return lista;
    }
}
