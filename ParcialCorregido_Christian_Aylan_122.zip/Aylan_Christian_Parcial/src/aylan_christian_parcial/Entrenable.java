package aylan_christian_parcial;

/**
 * Capacidad de tener un entrenamiento especial
 */
public interface Entrenable {

    /**
     * Descripcion del entrenamiento especial
     *
     * @return texto del entrenamiento
     */
    String entrenar();
}
