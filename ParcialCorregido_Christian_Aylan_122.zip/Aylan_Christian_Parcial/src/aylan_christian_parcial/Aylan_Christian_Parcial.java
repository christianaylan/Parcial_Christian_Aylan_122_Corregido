package aylan_christian_parcial;

import java.util.List;

public class Aylan_Christian_Parcial {

    public static void main(String[] args) {
        GremioAventureros gremio = new GremioAventureros("Guardianes de Eldoria");
        try {
            gremio.agregarAventurero(new Guerrero("G-01", "Arin", Rango.ORO, 30));
            gremio.agregarAventurero(new Mago("M-02", "Lyra", Rango.PLATA, 45));
            gremio.agregarAventurero(new Arquero("A-03", "Nox", Rango.BRONCE, 18));
            gremio.agregarAventurero(new Guerrero("G-04", "Borin", Rango.PLATA, 20));
            gremio.agregarAventurero(new Mago("G-01", "Arin", Rango.BRONCE, 99));
        } catch (AventureroRepetidoException exc) {
            System.out.println(exc.getMessage());
        }

        System.out.println("Aventureros registrados:");
        mostrarAventureros(gremio.obtenerAventureros());

        System.out.println("\nAtaques:");
        mostrarAtaques(gremio.obtenerAventureros());

        System.out.println("\nEntrenamientos:");
        mostrarEntrenamientos(gremio.obtenerAventureros());

        System.out.println("\nPoder de combate:");
        mostrarPoderes(gremio.obtenerAventureros());

        System.out.println("\nAventureros de rango PLATA:");
        mostrarAventureros(gremio.filtrarPorRango(Rango.PLATA));

        System.out.println("\nAventureros con poder >= 55:");
        mostrarAventureros(gremio.obtenerAventurerosPoderosos(55));
    }

    private static void mostrarAventureros(List<Aventurero> aventureros) {
        if (aventureros.isEmpty()) {
            System.out.println("Lista de aventureros vacia");
        }
        for (Aventurero av : aventureros) {
            System.out.println(av);
        }
    }

    private static void mostrarAtaques(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            System.out.println(av.atacar());
        }
    }

    private static void mostrarEntrenamientos(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            if (av instanceof Entrenable ent) {
                System.out.println(ent.entrenar());
            } else {
                System.out.println(av.getNombre() + " no tiene un entrenamiento especial");
            }
        }
    }

    private static void mostrarPoderes(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            System.out.println(av.getNombre() + " " + av.poderDeCombate());
        }
    }
}
